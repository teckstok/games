Modular Space Raider
by MuHa Games
v. 1.1 April 2014
contact: avee@muhagames.com


Thank you for buying Modular Space Raider pack!
This pack contains 8 unique modules, which you can use to construct a variety of space crafts. 
All modules share one 1024x1024 diffuse + specular .tif texture. The package contains two texture sets and also a custom shader that lets your colorize your ships (instructions on how to use the shader are in Shader folder). There are 4 premade ships included too.
Each module is made into a prefab, simply drag and drop required modules into hierarchy, move, rotate and resize them to assemble a new ship. Once ready, 
parent those modules to an empty game object, which you can then make into a prefab and voila!


Changelog

1.1 April 2014
- removed afterburner lights from the first set of textures
- added another set of textures 
- added custom colorizing shader

1.0 March 2014
- initial release
